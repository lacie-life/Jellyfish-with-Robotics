function [h, H_x] = measurementFunction(x, idxLandmark)
% [h, H_x] = measurementFunction(x, idxLandmark) returns the predicted measurement
% given a state x and a single map entry with index idxLandmark. H_x denotes the Jacobian of the
% measurement function with respect to the state evaluated at the state
% provided.
% Map entry and state are defined according to the book pp. 337-338

%Extract individual landmark from the state vector
m = x(3+2*(idxLandmark-1)+1:3+2*(idxLandmark));


h  = TODO

H_x = zeros(2,length(x));

H_x(1:2,1:3) = TODO

%Do not correct first two landmarks as they remain fixed
if (idxLandmark>2)

   H_x(1,3 + (idxLandmark-1)*2+1) = TODO;
   H_x(2,3 + (idxLandmark-1)*2+1) = TODO;
   H_x(1,3 + (idxLandmark)*2) = TODO;
   H_x(2,3 + (idxLandmark)*2) = TODO;
end

[h(1), h(2), isRNegated] = normalizeLineParameters(h(1), h(2));

if isRNegated 
    H_x(2, :) = - H_x(2, :);
end
